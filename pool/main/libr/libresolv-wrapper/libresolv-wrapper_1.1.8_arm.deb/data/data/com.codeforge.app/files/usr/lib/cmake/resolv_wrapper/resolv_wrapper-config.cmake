set(RESOLV_WRAPPER_LIBRARY /data/data/com.codeforge.app/files/usr/lib/libresolv_wrapper.so)

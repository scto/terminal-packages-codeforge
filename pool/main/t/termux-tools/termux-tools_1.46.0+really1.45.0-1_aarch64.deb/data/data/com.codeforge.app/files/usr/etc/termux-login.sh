##
## This script is sourced by /data/data/com.codeforge.app/files/usr/bin/login before executing shell.
##

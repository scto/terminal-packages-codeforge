if [ ! -f /data/data/com.codeforge.app/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.codeforge.app/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.codeforge.app/files/home/.termux
	cp /data/data/com.codeforge.app/files/usr/share/examples/termux/termux.properties /data/data/com.codeforge.app/files/home/.termux/
fi

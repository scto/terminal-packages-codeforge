#!/data/data/com.codeforge.app/files/usr/bin/sh

echo "$@"

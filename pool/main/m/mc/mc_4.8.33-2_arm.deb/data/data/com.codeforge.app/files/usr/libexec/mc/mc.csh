alias mc 'source /data/data/com.codeforge.app/files/usr/libexec/mc/mc-wrapper.csh'

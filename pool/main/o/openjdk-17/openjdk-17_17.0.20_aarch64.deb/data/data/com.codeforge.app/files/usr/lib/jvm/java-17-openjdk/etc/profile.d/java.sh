export JAVA_HOME=/data/data/com.codeforge.app/files/usr/lib/jvm/java-17-openjdk/
